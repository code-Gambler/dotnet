﻿
Web App Project Template V3

With security
Individual user accounts

Claims-aware
Programmer must customize the Register-related claims code
